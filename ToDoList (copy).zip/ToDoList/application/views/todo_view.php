<html>
   <head>
     <link href="<?php echo base_url('assests/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
     <link href="<?php echo base_url('assests/datatables/css/dataTables.bootstrap.css')?>" rel="stylesheet">
      <link rel="stylesheet" href="https://storage.googleapis.com/code.getmdl.io/1.0.6/material.indigo-pink.min.css">
	  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="https://storage.googleapis.com/code.getmdl.io/1.0.6/material.min.js"></script>
      <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons"/>
 </head>

     <body>
   <form id="form1" name="form1" method="post" action="">
  <p>
    <label for="user_role">Select a Role</label>
    <select name="user_role" id="user_role">
          <?php foreach($user as $data){?>
          <option><?php echo $data->user_role; ?></option>
          <?php } ?>
        </select>
    </label>






   <script>
  $( function() {
    $( "#datepicker" ).datepicker({
      showOn: "button",
      buttonImage: "/images/calendaricon.png/",
      buttonImageOnly: true,
      buttonText: "Select date"
    });
  } );
  </script>
  <p>Date: <input type="text" id="datepicker"></p>
   </form>
<p>&nbsp;</p>


<!--Fixed tab example -->
<div class="pmd-card pmd-z-depth">
  <div class="pmd-tabs pmd-tabs-bg">
	  <div class="pmd-tab-active-bar"></div>
	  <ul role="tablist" class="nav nav-tabs nav-justified">
		<li class="active" role="presentation"><a data-toggle="tab" role="tab" aria-controls="home" href="#home-fixed">ALL</a></li>
		<li role="presentation"><a data-toggle="tab" role="tab" aria-controls="profile" href="#about-fixed">PENDING</a></li>
		<li role="presentation"><a data-toggle="tab" role="tab" aria-controls="messages" href="#work-fixed">COMPLETED</a></li>
	  </ul>
  </div>
  <div class="pmd-card-body">
	  <div class="tab-content">
		<div role="tabpanel" class="tab-pane active" id="home-fixed">
      <table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
      <tbody>
      <?php foreach($todo as $book){?>
      <div class="list_item">
       <tr>
           <td><?php echo $book->todo_name;?></td>
       </tr>
        </div>
       <?php } ?>
      </tbody>
      </table>
    </div>

<!-- start of tab-pane 2 -->
    <div role="tabpanel" class="tab-pane" id="about-fixed">
      <table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
      <tbody>
      <?php foreach($todo as $book){?>
      <div class="list_item">
       <tr>
           <td><?php echo $book->todo_name;?></td>
       </tr>
        </div>
       <?php } ?>
      </tbody>
      </table>
    </div> <!-- end of tab pane2 -->

<!-- start of tab pane3 -->
		<div role="tabpanel" class="tab-pane" id="work-fixed">
      <table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
      <tbody>
      <?php foreach($todo as $book){?>
      <div class="list_item">
       <tr>
           <td><?php echo $book->todo_name;?></td>
       </tr>
        </div>
       <?php } ?>
      </tbody>
      </table>
    </div><!-- end of tab pane3 -->
	  </div>
  </div>
</div> <!--Fixed tab example end-->

<div class="show_more_main" id="show_more_main11">
                <span id="11" class="show_more" title="Load more posts">Show more</span>
                <span class="loding" style="display: none;"><span class="loding_txt">Loading...</span></span>
            </div>

   </body>
</html>
