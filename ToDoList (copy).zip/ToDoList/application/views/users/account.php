<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>To-Do List</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">

        <link rel="stylesheet" href="https://storage.googleapis.com/code.getmdl.io/1.0.6/material.indigo-pink.min.css">
        <script src="https://storage.googleapis.com/code.getmdl.io/1.0.6/material.min.js"></script>
        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<link href ="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/4.0.2/bootstrap-material-design.css"/>
<link href="<?php echo base_url(); ?>assets/css/style.css" rel='stylesheet' type='text/css' />
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="localhost/ci/shruti/assets/css/bootstrap-theme.min.css.map" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="localhost/ci/shruti/assets/css/bootstrap-theme.min.css.map" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="localhost/ci/shruti/assets/css/bootstrap-theme.min.css.map" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

</head>
<body>
  <div align:right>
  <script>  <!-- datepicker -->
  $( function() {
    $( "#datepicker" ).datepicker({
      showOn: "button",
      buttonImage: "images/calendar.gif",
      buttonImageOnly: true,
      buttonText: "Select date"
    });
  } );
  </script>
</div>
  <h1> <center> To-Do List </center></h1>
<div id="container">
  <div id="left"> <!-- account details shown at the left side-->
    <h2>User Account</h2>
    <h3>Welcome <?php echo $user['name']; ?>!</h3>
    <div class="account-info">
        <p><b>Name: </b><?php echo $user['name']; ?></p>
        <p><b>Email: </b><?php echo $user['email']; ?></p>
        <p><b>Role: </b><?php echo $user['role'];?> </p>
        <p><b>Department:</b><?php echo $user['dept'];?> </p>
    </div>
</div>
<a href="logout">Logout</a>
<div id=""> <!-- details of the tasks on the right side-->
  To Do: <input type ="text" name="text"/>
  Users: <input type ="text" name="users"/>


<p>Date: <input type="text" id="datepicker"></p>
<div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
      <header class="mdl-layout__header">
         <div class="mdl-layout__header-row" align ="center">
            <span class="mdl-layout-title">List of the tasks</span>
         </div>
      </header>
      <main class="mdl-layout__content">
         <div class="mdl-tabs mdl-js-tabs">
            <div class="mdl-tabs__tab-bar">
               <a href="#tab1-panel" class="mdl-tabs__tab is-active">All</a>
               <a href="#tab2-panel" class="mdl-tabs__tab">Pending</a>
               <a href="#tab3-panel" class="mdl-tabs__tab">Done</a>
            </div>
            <div class="mdl-tabs__panel is-active" id="tab1-panel">
               <p>Tab 1 Content</p>
            </div>
            <div class="mdl-tabs__panel" id="tab2-panel">
               <p>Tab 2 Content</p>
            </div>
            <div class="mdl-tabs__panel" id="tab3-panel">
               <p>Tab 3 Content</p>
            </div>
         </div>
	  </main>
   </body>
</html>
</div>
</div>


</body>
</html>
