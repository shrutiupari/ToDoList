<p> You have logged out successfully</p>
