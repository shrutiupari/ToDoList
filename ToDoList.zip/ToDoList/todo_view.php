<html>
<head>
<link href="<?php echo base_url('assests/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
<link href="<?php echo base_url('assests/datatables/css/dataTables.bootstrap.css')?>" rel="stylesheet">
<link rel="stylesheet" href="https://storage.googleapis.com/code.getmdl.io/1.0.6/material.indigo-pink.min.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="https://storage.googleapis.com/code.getmdl.io/1.0.6/material.min.js"></script>
      <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons"/>
 </head>
 <body>
 <script>
  $( function() {
    $( "#datepicker" ).datepicker({
      showOn: "button",
      //buttonImage: "/images/calendaricon.png/",
      buttonImageOnly: true,
      //buttonText: "Select date"
    });
  });
  </script>
  <p>Date: <input type="text" id="datepicker"></p>
   </form>
<p>&nbsp;</p>

<style>
body {font-family: "Lato", sans-serif;}

/* Style the tab */
div.tab {
    overflow: hidden;
    border: 1px solid #ccc;
    background-color: #f1f1f1;
}

/* Style the buttons inside the tab */
div.tab button {
    background-color: inherit;
    float: left;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 14px 16px;
    transition: 0.3s;
    font-size: 17px;
}

/* Change background color of buttons on hover */
div.tab button:hover {
    background-color: #ddd;
}

/* Create an active/current tablink class */
div.tab button.active {
    background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
    display: none;
    padding: 6px 12px;
    border: 1px solid #ccc;
    border-top: none;
}
</style>
<div class="tab">
  <button class="tablinks" onclick="openTodo(event, 'All')">All</button>
  <button class="tablinks" onclick="openTodo(event, 'Pending')">Pending</button>
  <button class="tablinks" onclick="openTodo(event, 'Completed')">Completed</button>
  
</div>

<div id="All" class="tabcontent">
    <!--<h3>All</h3>-->
      <?php foreach($todo as $book){?>
      <div class="list_item">
     
          <?php echo $book->todo_name;?>
       <form action="#" method="GET">
          <input type="checkbox" name="todo_name" id="todo_name" value="$book"><br>
          
       </form>
     
        </div>
       <?php } ?>

 
</div>

<div id="Pending" class="tabcontent">
  <!--<h3>Pending</h3>-->
  
  <?php foreach($info as $status){?>
      <div class="list_item">
      <?php echo $status->todo_name;?>
    </div>
       <?php } ?>
</div>

<div id="Completed" class="tabcontent">
  <!--<h3>Completed</h3>-->
  </div>
<input type="submit" name="submit" value="Done" onclick="done()"/>


<script>
    $(document).ready( function () {
      $('#todo_name').DataTable();
  } );
    var save_method; //for save method string
    var table;
    
    
function openTodo(evt, Name) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(Name).style.display = "block";
    evt.currentTarget.className += " active";
}

function done()
    {
      var url;
      if(save_method == 'add')
      {
          url = "<?php echo site_url('index.php/User/saveForm')?>";
      }
      else
      {
        url = "<?php echo site_url('index.php/User/todo_update')?>";
      }

       // ajax adding data to database
          $.ajax({
            url : url,
            type: "POST",
            data: $('#form').serialize(),
            dataType: "JSON",
            success: function(data)
            {
               //if success close modal and reload ajax table
               $('#modal_form').modal('hide');
              location.reload();// for reload a page
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
            }
        });
    }
</script>
   </body>
</html>
