<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model
{

	var $table = 'users';

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		//$this->userTbl = 'users';
	}


public function get_all_users()
{
$this->db->from('users');
$query=$this->db->get();
return $query->result();
}

// <!-- to get data from other table named todo
public function get_all_data()
{
	$this->db->from('todo');
	$query=$this->db->get();
	return $query->result();
}
// end of get_all_data() -->

public function get_user()
{
	$this->db->from($this->table);
	$this->db->where('user_role');
	return $query->result();
}
 public function user_status_pending()
        {
            $this->db->select('todo_name');
        $this->db->from('todo');
	$this->db->where('status=1');
        $query = $this->db->get();
		return $query->result();

        }
//to store checked data in to database
        public function saveForm($data)
        {
            $this->db->insert('todo', $data);
          $query= $this->db->get();
return $query->result();					 

        }

        public function todo_update($where,$data)
        {
            $this->db->update('todo', $data, $where);
		return $this->db->affected_rows();
        }

//        to get users by id
	public function get_by_id($id)
	{
		$this->db->from($this->table);
		$this->db->where('user_id',$id);
		$query = $this->db->get();

		return $query->row();
	}

	public function user_add($data)
	{
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}

	public function user_update($where, $data)
	{
		$this->db->update($this->table, $data, $where);
		return $this->db->affected_rows();
	}

	public function delete_by_id($id)
	{
		$this->db->where('user_id', $id);
		$this->db->delete($this->table);
	}

        public function get_user_role($data)
        {
            $this->db->where('user_role',$data);
        }

}
