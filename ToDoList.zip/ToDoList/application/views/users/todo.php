<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>To Do listt</title>
<link href ="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/4.0.2/bootstrap-material-design.css"/>
<style type="text/css">
<!--
#Layer1 {
	position:absolute;
	width:1106px;
	height:360px;
	z-index:1;
	left: 5px;
	top: 255px;
}
-->
</style>
<div align:right>
  <script>  <!-- datepicker -->
  $( function() {
    $( "#datepicker" ).datepicker({
      showOn: "button",
      buttonImage: "images/calendar.gif",
      buttonImageOnly: true,
      buttonText: "Select date"
    });
  } );
  </script>
</div>
</head>

<body>
<div class="row" id="row">
  <form id="form1" name="form1" method="post" action="">
    <label>To Do List
      <input type="text" name="textfield" />
      Priority:    </label>
    <select name="select2">
    </select>
  <p>Date: <input type="text" id="datepicker"></p>
  </form>
  <form id="form2" name="form2" method="post" action="">
    <label>
      <input type="checkbox" name="checkbox" value="checkbox" />
      For Others:
      <select name="select">
      </select>
    </label>
    <p>&nbsp;</p>
  </form>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>
<div id="Layer1">
  <div class="mdl-tabs mdl-js-tabs">
    <div class="mdl-tabs__tab-bar">
      <div class="mdl-layout__header-row" align ="center"> <span class="mdl-layout-title">List of the tasks</span> </div>
      <p><a href="#tab1-panel" class="mdl-tabs__tab is-active">All</a> <a href="#tab2-panel" class="mdl-tabs__tab">Pending</a> <a href="#tab3-panel" class="mdl-tabs__tab">Done</a> </p>
    </div>
    <div class="mdl-tabs__panel is-active" id="tab1-panel">
      <p>Tab 1 Content</p>
    </div>
    <div class="mdl-tabs__panel" id="tab2-panel">
      <p>Tab 2 Content</p>
    </div>
    <div class="mdl-tabs__panel" id="tab3-panel">
      <p>Tab 3 Content</p>
    </div>
  </div>
</div>
<p>&nbsp;</p>
</body>
</html>
