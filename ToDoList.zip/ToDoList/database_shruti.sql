-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 25, 2017 at 06:27 PM
-- Server version: 5.7.18-0ubuntu0.16.04.1
-- PHP Version: 7.0.15-0ubuntu0.16.04.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_shruti`
--

-- --------------------------------------------------------

--
-- Table structure for table `todo`
--

CREATE TABLE `todo` (
  `todo_id` int(50) NOT NULL,
  `todo_name` varchar(50) NOT NULL,
  `todo_work` text NOT NULL,
  `status` tinyint(1) DEFAULT '0',
    PRIMARY KEY (todo_id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `todo`
--

INSERT INTO `todo` (`todo_id`, `todo_name`, `todo_work`, `status`) VALUES
(1, 'Early Morning', 'I have to go fro yoga classes', 1),
(2, 'After 10am', 'I have to start my work', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (

  `user_id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_role` varchar(50) NOT NULL,
  `user_department` varchar(100) NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gender` enum('Male','Female') COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--
INSERT INTO `users` (`id`, `name`, `email`, `password`, `gender`, `phone`, `created`, `modified`, `role`, `dept`, `status`) VALUES
(1, 'shruti', 'shrutiupari@gmail.com', 'eab6930b3c87b22874b40a0e52fe1ca3', 'Female', '8762164257', '2017-05-23 09:20:53', '2017-05-23 09:20:53', 'Trainee', 'Developer', '1'),
(2, 'preeti', 'upari.preeti@gmail.com', '48d9d2bbfdb0d128464d3d7ecfa626b4', 'Female', '9731613257', '2017-05-23 11:14:50', '2017-05-23 11:14:50', 'Trainee', 'Testing', '1'),
(3, 'tushar', 'tusharupari@gmail.com', 'df7c905d9ffebe7cda405cf1c82a3add', 'Male', '1234567890', '2017-05-24 09:43:03', '2017-05-24 09:43:03', 'Manager', 'Developer', '1'),
(4, 'Shruti', 'shruti@gmail.com', 'af15d5fdacd5fdfea300e88a8e253e82', 'Female', '8762164257', '2017-05-26 09:31:16', '2017-05-26 09:31:16', '', '', '1');

-- Indexes for dumped tables
--

--
-- Indexes for table `todo`
--
ALTER TABLE `todo`
  ADD PRIMARY KEY (`todo_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `todo`
--
ALTER TABLE `todo`
  MODIFY `todo_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
